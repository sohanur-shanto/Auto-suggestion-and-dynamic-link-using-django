from django.contrib import admin
from .models import CredentialsModel
from django.urls import reverse

# Register your models here.
admin.site.register(CredentialsModel)

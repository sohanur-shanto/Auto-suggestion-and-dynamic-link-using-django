from django.db import models
from oauth2client.contrib.django_util.models import CredentialsField
from django.urls import reverse


class CredentialsModel(models.Model):
    credential = CredentialsField()
from django.shortcuts import render
from django.views.generic import TemplateView
from django import forms
from django.views.generic.edit import FormView


class HomePageView(TemplateView):
    template_name = 'core/home.html'



class YouTubeForm(forms.Form):
    pass


class HomePageView(FormView):
    template_name = 'core/home.html'
    form_class = YouTubeForm